__author__ = 'wenzou'


def validate():
    print "validate"